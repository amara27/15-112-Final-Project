#    15-112: Principles of Programming and Computer Science
#    HW07 Programming: Final Project - World Cup 2022
#    Name      : Mohamed Amara
#    AndrewID  : mamra

#    File Created: 11/10/2017
#    Modification History:
#    Start:                 End:
#    10/11    5:45pm        11/11    01:51am
#    11/11    11:30am       11/11    04:00pm
#    11/11    08:30pm       11/11    03:03pm
#    12/11    03:55pm       12/11    05:20pm



from Tkinter import*
import random 



class homepage():
    def __init__(self,parent):
        self.parent=parent
        self.canvas=Canvas(parent,heigh=760,width=800)
        self.canvas.pack()

        self.canvas.create_image(400,360,image=mainM)

        
        self.nameE=Entry(parent,width=25,relief=FLAT)
        self.canvas.create_window(686, 470, window=self.nameE)

        self.arrivalE=Entry(parent,width=20,relief=FLAT)
        self.canvas.create_window(702, 553, window=self.arrivalE)

        self.departureE=Entry(parent,width=17,relief=FLAT)
        self.canvas.create_window(720, 630, window=self.departureE)
        

        self.startB=Button(parent,text="Start",command=self.matchesPre,bg="dark red")
        self.canvas.create_window(550, 340, window=self.startB)
        
    def matchesPre(self):
        self.canvas.destroy()
        MatchesPre(self.parent)


class MatchesPre():
    def __init__(self,parent):
        self.canvas=Canvas(parent,heigh=800,width=800)
        self.canvas.pack()
        self.canvas.create_image(400,360,image=prefrences)
        self.parent=parent
        
        self.nationalityE=Entry(parent,relief=FLAT)
        self.canvas.create_window(130,375,window=self.nationalityE)

        self.leagueE=Entry(parent,relief=FLAT)
        self.canvas.create_window(585,375,window=self.leagueE)

        self.coachE=Entry(parent,relief=FLAT)
        self.canvas.create_window(130,560,window=self.coachE)

        self.player1E=Entry(parent,relief=FLAT)
        self.canvas.create_window(523,530,width=130,window=self.player1E)

        self.player2E=Entry(parent,relief=FLAT)
        self.canvas.create_window(670,530,width=130,window=self.player2E)

        self.player3E=Entry(parent,relief=FLAT)
        self.canvas.create_window(523,580,width=130,window=self.player3E)

        self.player4E=Entry(parent,relief=FLAT)
        self.canvas.create_window(670,580,width=130,window=self.player4E)

        self.numMatchesE=Entry(parent,relief=FLAT)
        self.canvas.create_window(400,250,width=50,window=self.numMatchesE)

        
        self.time1Value=IntVar()
        self.time1Value.set(0)
        self.time1=Checkbutton(parent,variable=self.time1Value, onvalue=1, offvalue=0,text="19pm",bg="dark red")
        self.canvas.create_window(85,680,width=130,window=self.time1)

        self.time2Value=IntVar()
        self.time2Value.set(0)
        self.time2=Checkbutton(parent,variable=self.time2Value, onvalue=1, offvalue=0,text="22pm",bg="dark red")
        self.canvas.create_window(255,680,width=130,window=self.time2)

        self.time3Value=IntVar()
        self.time3Value.set(0)
        self.time3=Checkbutton(parent,variable=self.time3Value, onvalue=1, offvalue=0,text="23pm",bg="dark red")
        self.canvas.create_window(412,680,width=130,window=self.time3)

        self.time4Value=IntVar()
        self.time4Value.set(0)
        self.time4=Checkbutton(parent,variable=self.time4Value, onvalue=1, offvalue=0,text="01am",bg="dark red")
        self.canvas.create_window(572,680,width=130,window=self.time4)

        self.time5Value=IntVar()
        self.time5Value.set(0)
        self.time5=Checkbutton(parent,variable=self.time5Value, onvalue=1, offvalue=0,text="04am" ,bg="dark red")
        self.canvas.create_window(720,680,width=130,window=self.time5)
        
        
        self.nextButton=Button(parent,text="NEXT",command=self.schedule, fg="light green", bg="light green")
        self.canvas.create_window(750, 50, window=self.nextButton)

        self.backButton=Button(parent,text="BACK",command=self.back, fg="light green", bg="light green")
        self.canvas.create_window(750, 100, window=self.backButton)

    def schedule(self):
        timings=[]

        if self.time1Value.get()==1:
            timings.append("19pm")
        if self.time2Value.get()==1:
            timings.append("22pm")
        if self.time3Value.get()==1:
            timings.append("23pm")
        if self.time4Value.get()==1:
            timings.append("01am")
        if self.time5Value.get()==1:
            timings.append("04am")
        fileWC.seek(0)
        data= fileWC.readlines()
        if self.numMatchesE.get()=="":
            self.wnd = Toplevel()
            self.label = Label(self.wnd, text ="Please provide the number of matches you would like to attend") 
            self.label.pack()
        elif self.nationalityE.get()=="":
            self.wnd = Toplevel()
            self.label = Label(self.wnd, text ="Please provide the country of origin") 
            self.label.pack()
            
        elif self.leagueE.get()=="":
            self.wnd = Toplevel()
            self.label = Label(self.wnd, text ="Please provide your favourite league") 
            self.label.pack()

        elif self.coachE.get()=="":
            self.wnd = Toplevel()
            self.label = Label(self.wnd, text ="Please provide your favourite coach") 
            self.label.pack()
            
        elif "" in [self.player1E.get(), self.player2E.get(), self.player3E.get(), self.player4E.get()]:
            self.wnd = Toplevel()
            self.label = Label(self.wnd, text ="Please provide your favourite 4 players") 
            self.label.pack()
        
        else:
            self.canvas.destroy()
            algorithim(self.numMatchesE.get(), self.nationalityE.get(), self.leagueE.get(), self.coachE.get(), [self.player1E.get(), self.player2E.get(), self.player3E.get(), self.player4E.get()], timings,data,self.parent) 
    
        
    def back(self):
        self.canvas.destroy()
        homepage(self.parent)

class algorithim():
    def __init__(self,numMatches,nationality,favLeague,favCoach,favPlayers,favTimings,data,parent):
        self.parent=parent
        self.points={}
        self.teams={}
        self.coaches={}
        self.matches={}
        self.chosenMatches=[]
        
        for team in data[:33]:
            team=team.split()
            self.points[team[0]]=0
            self.coaches[team[0]]=team[1]

            players=[]
            leagues=[]
            for i in range(2,len(team),2):
                players.append(team[i])
                leagues.append(team[i+1])
            
            self.teams[team[0]]=(players,leagues)
        
        for match in data[32:]:
            match=match.split()
            self.matches[match[0]+" "+match[1]+" "+match[2]+" "]=[match[3],0]

        # Nationality ==> 5000:
        if nationality in self.points.keys():
            self.points[nationality]+=5000
           
        
        # Favourite League ==> 20: 
        for team in self.teams.keys():
            self.points[team]+=self.teams[team][1].count(favLeague)*20
            

        # Favourite players ==> 30:
        for favPlayer in favPlayers:
            for team in self.teams.keys():
                for player in self.teams[team][0]:
                    if favPlayer==player:
                        self.points[team]+=30
        # Favourite Coach ==> 25:
        for team in self.coaches.keys():
            if self.coaches[team]==favCoach:
                self.points[team]+=25

        # Adding points to the matches:
        for match in self.matches.keys():

            self.matches[match][1]+=self.points[match.split()[0]]+self.points[match.split()[2]]

        # Favourite Timings ==> 15: 
        for time in favTimings:
            for match in self.matches.keys():
                if time==self.matches[match][0]:
                    self.matches[match][1]+=15
        tempPoints=[]
        for match in self.matches.keys():
            tempPoints.append(self.matches[match][1])
  
        matchInd=[]
        for i in range(int(numMatches)):
            matchInd.append(tempPoints.index(max(tempPoints)))
            tempPoints[tempPoints.index(max(tempPoints))]=0
        for index in matchInd:
            
            if self.matches.keys()[index] in self.chosenMatches:
                self.chosenMatches.append(self.matches.keys()[random.randint(index,48)])
            else:
                self.chosenMatches.append(self.matches.keys()[index])
        
        schedule(self.parent,self.chosenMatches)
            
   
        
            
class schedule():
    def __init__(self,parent,matches):
        self.parent=parent
        self.canvas=Canvas(parent,heigh=700,width=800,bg="light green")
        self.canvas.pack()
        self.backButton=Button(parent,text="BACK",command=self.back, fg="light green", bg="light green")
        self.canvas.create_window(750, 100, window=self.backButton)
        center=60
        
        for i in range(len(matches)):
            if i==0:
                self.canvas.create_rectangle(400-130,center-20,400+130,center+20,fill="yellow")
                self.canvas.create_text(400,center,text=matches[i])
            
            self.canvas.create_rectangle(400-130,center-20,400+130,center+20,fill="yellow")
            self.canvas.create_text(400,center,text=matches[i])
            center+=(700/len(matches))

    def back(self):
        self.canvas.destroy()
        MatchesPre(self.parent)
        
            
        

        
wnd=Tk()
wnd.geometry("800x700")
wnd.resizable(width = False, height = False)

# Images:
mainM = PhotoImage(file="bg.gif")
prefrences = PhotoImage(file="prefrences.gif")
fileWC=open("WC.txt")

app=homepage(wnd)
wnd.mainloop()

        
